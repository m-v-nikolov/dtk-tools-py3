# Init for results
