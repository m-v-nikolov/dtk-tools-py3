
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.6.1'
version = '0.6.1'
full_version = '0.6.1'
git_revision = '50b474fda484ea4614185ab51f1ae3ed9c9296e8'
release = True

if not release:
    version = full_version