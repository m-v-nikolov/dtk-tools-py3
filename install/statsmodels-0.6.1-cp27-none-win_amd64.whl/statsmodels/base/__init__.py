from statsmodels import NoseWrapper as Tester
test = Tester().test
