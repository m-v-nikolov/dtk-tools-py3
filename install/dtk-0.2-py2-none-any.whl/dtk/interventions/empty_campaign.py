empty_campaign = { "Campaign_Name" : "Empty Campaign",
                   "Use_Defaults"  : 1,
                   "Events"        : [] 
                 }