from CustomReport import *
from MalariaReport import *