from CustomReport import *
from MalariaReport import *
from VectorReport import *